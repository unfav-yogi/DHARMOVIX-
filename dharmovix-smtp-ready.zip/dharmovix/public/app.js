'use strict';
const $ = s => document.querySelector(s), view = $('#view');
const e = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const CATS = ['Hackathon', 'Workshop', 'Internship', 'Course'], PLURAL = { Hackathon: 'Hackathons', Workshop: 'Workshops', Internship: 'Internships', Course: 'Courses' };
const QUOTES = ['Every expert was once a beginner.', 'Learn today. Build tomorrow.', 'Skills create opportunities.', 'Your next opportunity could be one click away.', 'Learn. Build. Grow. Create Your Opportunity.'];
let me = { user: null, admin: null };

async function api(url, o = {}) {
  const opt = { method: o.method || 'GET', headers: { 'X-Requested-With': 'dharmovix' }, credentials: 'same-origin' };
  if (o.body instanceof FormData) opt.body = o.body; else if (o.body) { opt.body = JSON.stringify(o.body); opt.headers['Content-Type'] = 'application/json'; }
  const r = await fetch('/api' + url, opt), d = await r.json().catch(() => ({}));
  if (!r.ok) { const err = new Error(d.error || 'Request failed.'); err.status = r.status; throw err; }
  return d;
}
function toast(msg, bad) { const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), 4200); }
const pill = s => `<span class="pill ${e(String(s).toLowerCase().replace(/ /g, '-'))}">${e(s)}</span>`;
const fmtDate = d => d ? new Date(d.length === 10 ? d + 'T00:00:00' : d.replace(' ', 'T') + 'Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'TBA';
const imageUrl = value => /^https?:\/\//i.test(String(value || '')) ? String(value) : `/uploads/${e(value)}`;
const img = o => o.image ? `<img src="${e(imageUrl(o.image))}" alt="" loading="lazy">` : '';
function confirmBox(msg, label = 'Delete') {
  return new Promise(res => { const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div role="dialog" aria-modal="true"><h3>${e(msg)}</h3><div class="acts" style="margin-top:18px"><button class="btn bad" id="y">${e(label)}</button><button class="btn ghost" id="n">Cancel</button></div></div>`;
    document.body.append(m); m.querySelector('#y').onclick = () => { m.remove(); res(true); }; m.querySelector('#n').onclick = () => { m.remove(); res(false); }; });
}
function modal(html) { const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div role="dialog" aria-modal="true">${html}</div>`; document.body.append(m);
  m.addEventListener('mousedown', ev => { if (ev.target === m) m.remove(); }); m.close = () => m.remove(); return m; }

/* ---------- Intro (butterflies) ---------- */
const BF = c => `<svg viewBox="0 0 60 50"><g><path d="M30 25C22 4 4 2 3 14c-1 11 12 16 27 11z" fill="${c[0]}"/><path d="M30 25C20 38 10 50 18 48c9-2 14-11 12-23z" fill="${c[1]}"/>
<path d="M30 25C38 4 56 2 57 14c1 11-12 16-27 11z" fill="${c[0]}"/><path d="M30 25C40 38 50 50 42 48c-9-2-14-11-12-23z" fill="${c[1]}"/></g><rect x="29" y="14" width="2" height="26" rx="1" fill="#fff"/></svg>`;
function intro() {
  if (sessionStorage.dvIntro || location.hash.startsWith('#/admin')) return;
  const el = $('#intro'); el.hidden = false; document.body.style.overflow = 'hidden';
  const cols = [['#E2B54A', '#C8962E'], ['#7EA2FF', '#3D63D6'], ['#F4D58D', '#C8962E']];
  let f = ''; for (let i = 0; i < 7; i++) f += `<div class="bf" style="top:${8 + i * 12}%;--t:${13 + i * 2}s;--d:${i * 1.4}s;--b:${2.2 + i * .3}s;--s:${30 + (i % 3) * 14}px"><div>${BF(cols[i % 3])}</div></div>`;
  for (let i = 0; i < 18; i++) f += `<i class="dot" style="left:${Math.random() * 100}%;top:${Math.random() * 100}%;--t:${4 + Math.random() * 5}s"></i>`;
  el.innerHTML = `${f}<div class="in"><img class="logo" src="/logo.png" alt="Dharmovix Technologies"><h1>Learn. Build. Grow.<br>Create Your Opportunity.</h1><div class="stage" id="stage">Growth</div><button class="btn" id="go">Get Started</button></div>`;
  const words = ['Growth', 'Learning', 'Transformation', 'Opportunity']; let i = 0;
  const t = setInterval(() => { i = (i + 1) % 4; $('#stage').textContent = words[i]; }, 1500);
  $('#go').onclick = () => { clearInterval(t); sessionStorage.dvIntro = 1; el.classList.add('out'); document.body.style.overflow = ''; setTimeout(() => { el.hidden = true; el.innerHTML = ''; el.classList.remove('out'); }, 850); };
  $('#go').focus();
}

/* ---------- Layout ---------- */
function nav() {
  const r = location.hash || '#/', on = h => r.startsWith(h) ? 'on' : '';
  const L = me.user
    ? `<a href="#/" class="${r === '#/' ? 'on' : ''}">Home</a><a href="#/opportunities" class="${on('#/opportunities')}">Opportunities</a><a href="#/achieve" class="${on('#/achieve')}">Achieve</a><a href="#/applications" class="${on('#/applications')}">My Applications</a><a href="#/profile" class="${on('#/profile')}">Profile</a><a href="#/opportunities" id="bell" aria-label="New opportunities" title="New opportunities">🔔<b id="bn" hidden></b></a><a href="#" id="out" class="cta">Logout</a>`
    : `<a href="#/" class="${r === '#/' ? 'on' : ''}">Home</a><a href="#/opportunities" class="${r === '#/opportunities' ? 'on' : ''}">Opportunities</a><a href="#/achieve" class="${on('#/achieve')}">Achieve</a><a href="#/about" class="${on('#/about')}">About</a><a href="#/admin-login">Admin Login</a><a href="#/login" class="${on('#/login')}">Login</a><a href="#/register" class="cta">Register</a>`;
  $('#nav').innerHTML = `<div class="wrap"><a class="brand" href="#/"><img src="/logo.png" alt="">Dharmovix</a><button id="burger" aria-label="Menu" aria-expanded="false">☰</button><nav id="links">${L}</nav></div>`;
  $('#burger').onclick = ev => { const o = $('#links').classList.toggle('open'); ev.target.setAttribute('aria-expanded', o); };
  $('#links').onclick = ev => { if (ev.target.id === 'out') { ev.preventDefault(); api('/logout', { method: 'POST' }).finally(() => { me.user = null; location.hash = '#/'; route(); }); } $('#links').classList.remove('open'); };
  bell();
}
async function bell() { // in-site notification: counts opportunities published since the user last opened Opportunities
  if (!me.user) return; const key = 'dvSeen_' + me.user.id;
  try { const l = await api('/opportunities'), mx = Math.max(0, ...l.map(o => o.id)); let s = localStorage.getItem(key);
    if (s === null || (location.hash || '').startsWith('#/opportunities')) { localStorage.setItem(key, mx); s = mx; }
    const n = l.filter(o => o.id > +s).length, b = $('#bn'); if (b) { b.hidden = !n; b.textContent = n; } } catch { }
}
function quote() { return `<p class="quote" id="q">“${e(QUOTES[Math.floor(Math.random() * QUOTES.length)])}”</p>`; }
let qt; function rotateQuotes() { clearInterval(qt); qt = setInterval(() => { const q = $('#q'); if (!q) return clearInterval(qt); q.classList.add('out'); setTimeout(() => { q.textContent = '“' + QUOTES[Math.floor(Math.random() * QUOTES.length)] + '”'; q.classList.remove('out'); }, 500); }, 6000); }
const page = (t, s, inner) => `<section class="pagehead"><div class="wrap"><h1>${e(t)}</h1><p>${e(s)}</p>${inner || ''}</div></section>`;
const card = o => `<article class="card"><div class="img">${e(o.category[0])}${img(o)}</div><div class="body"><span class="badge">${e(o.category)}</span><h3>${e(o.title)}</h3><p>${e(o.description)}</p>
<div class="meta"><span>📅 ${fmtDate(o.date)}</span><span>${o.my_status ? pill(o.my_status) : pill('Open')}</span></div><a class="btn navy sm" href="#/opportunity/${o.id}">View Details</a></div></article>`;

/* ---------- Public pages ---------- */
const pages = {};
pages.home = async () => {
  const list = await api('/opportunities').catch(() => []);
  view.innerHTML = `<section class="hero"><div class="wrap"><div><h1>Discover. Learn. Compete. Grow.</h1><p>Discover hackathons, workshops, internships and courses designed to help you build skills and create new opportunities.</p>
  <a class="btn" href="#/opportunities" style="margin-top:14px;font-size:17px;padding:15px 30px">Search Opportunities</a></div><img class="logo round" src="/logo.png" alt="Dharmovix Technologies"></div></section>
  <section class="sec alt"><div class="wrap">${quote()}</div></section>
  <section class="sec"><div class="wrap"><h2>Latest opportunities</h2><div class="grid">${list.slice(0, 4).map(card).join('') || '<p class="empty">New opportunities will appear here soon.</p>'}</div></div></section>`;
  rotateQuotes();
};
pages.opportunities = async params => {
  let cat = CATS.includes(params.get('c')) ? params.get('c') : '', q = (params.get('s') || '').slice(0, 80);
  const title = cat ? PLURAL[cat] : 'Opportunities';
  view.innerHTML = page(title, cat ? `Browse current ${PLURAL[cat].toLowerCase()}.` : 'Everything open right now.', `<div class="search"><input id="q" type="search" placeholder="Search opportunities, hackathons, internships, workshops or courses..." aria-label="Search" value="${e(params.get('s') || '')}"></div>
  <div class="chips">${['', ...CATS].map(c => `<button class="chip ${c === cat ? 'on' : ''}" data-c="${c}">${c ? PLURAL[c] : 'All'}</button>`).join('')}</div>`) + `<section class="sec"><div class="wrap"><div class="grid" id="res"></div></div></section>`;
  let tm, seq = 0;
  const load = async () => { const my = ++seq; $('#res').innerHTML = '<div class="skeleton"></div>'.repeat(3);
    try { const d = await api(`/opportunities?q=${encodeURIComponent(q)}&category=${cat}`); if (my !== seq) return; $('#res').innerHTML = d.map(card).join('') || '<p class="empty">No opportunities match your search. Try a different keyword or category.</p>'; }
    catch (x) { $('#res').innerHTML = `<p class="empty">${e(x.message)}</p>`; } };
  $('#q').oninput = ev => { clearTimeout(tm); q = ev.target.value; tm = setTimeout(load, 250); };
  document.querySelectorAll('.chip').forEach(b => b.onclick = () => { cat = b.dataset.c; document.querySelectorAll('.chip').forEach(x => x.classList.toggle('on', x === b)); load(); });
  load();
};
pages.opportunity = async id => {
  try { const o = await api('/opportunities/' + id);
    view.innerHTML = `<div class="wrap detail"><div><div class="big" style="aspect-ratio:16/9;border-radius:20px;overflow:hidden;background:linear-gradient(135deg,var(--navy),var(--navy2));position:relative">${img(o).replace('<img', '<img style="width:100%;height:100%;object-fit:cover"')}</div>
    <span class="badge" style="margin-top:20px">${e(o.category)}</span><h1 style="margin-top:8px">${e(o.title)}</h1><p style="white-space:pre-wrap">${e(o.description)}</p>
    ${o.additional_info ? `<h3>Important information</h3><p style="white-space:pre-wrap">${e(o.additional_info)}</p>` : ''}</div>
    <aside><div class="box"><p><b>Date</b><br>📅 ${fmtDate(o.date)}</p>${o.registration_link ? `<p><b>Registration link</b><br><a href="${e(o.registration_link)}" target="_blank" rel="noopener noreferrer">${e(o.registration_link)}</a></p>` : ''}
    ${o.my_status ? `<p>Your application: ${pill(o.my_status)}</p>` : `<button class="btn" id="apply" style="width:100%;justify-content:center">Apply / Register</button>`}</div></aside></div>`;
    const b = $('#apply'); if (b) b.onclick = async () => {
      if (!me.user) { toast('Please login to apply for this opportunity.', true); sessionStorage.dvReturn = location.hash; return setTimeout(() => location.hash = '#/login', 900); }
      b.disabled = true; try { await api(`/opportunities/${o.id}/apply`, { method: 'POST' }); toast('Application submitted.'); route(); } catch (x) { toast(x.message, true); b.disabled = false; } };
  } catch (x) { view.innerHTML = `<div class="wrap narrow"><h2>${e(x.message)}</h2><a class="btn" href="#/opportunities">Browse opportunities</a></div>`; }
};
pages.about = () => view.innerHTML = page('About Dharmovix', 'A student-focused technology and learning platform.') + `<section class="sec"><div class="wrap" style="max-width:860px">
<p>Dharmovix is a student-focused technology and learning platform designed to connect learners with valuable opportunities for growth. We bring together hackathons, workshops, internships, courses, and other learning opportunities in one easy-to-access platform.</p>
<p>Our goal is to help students discover new opportunities, develop practical skills, gain real-world experience, and move closer to their career goals. Whether you are a beginner looking to learn something new or a student searching for your next opportunity, Dharmovix is built to help you take the next step.</p>
<h2 style="margin-top:40px">What We Provide</h2><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr))">${[['🚀', 'Hackathons', 'Discover competitions where you can solve problems, build projects, and showcase your skills.'], ['📚', 'Courses', 'Explore learning resources and courses to improve your technical and professional knowledge.'], ['🛠️', 'Workshops', 'Participate in practical sessions and learn from hands-on experiences.'], ['💼', 'Internships', 'Find internship opportunities that can help you gain real-world industry exposure.'], ['🌱', 'Learning & Growth', 'Discover opportunities that help you continuously improve your skills and knowledge.']].map(([i, t, d]) => `<div class="tile"><b>${i} ${t}</b><span>${d}</span></div>`).join('')}</div>
<h2 style="margin-top:40px">Our Mission</h2><p>Our mission is to make learning and opportunities easier to discover and accessible to students.</p>
<p>We believe that every student deserves the opportunity to learn, build, participate, and grow. Dharmovix aims to create a platform where students can discover opportunities, develop skills, and turn their learning into real-world experiences.</p>
<h2 style="margin-top:40px">Our Vision</h2><p class="quote" style="margin:18px 0">“Learn. Build. Grow. Create Your Opportunity.”</p>
<p>We envision Dharmovix as a growing ecosystem where students can discover opportunities, gain knowledge, connect with experiences, and build a stronger future.</p></div></section>`;

const STAGES = ['Foundation', 'Core skills', 'Build projects', 'Level up', 'Get job-ready'];
const ROLES = [
['Data Scientist', '📊', 'data', 'Turns data into predictions and decisions using statistics and machine learning.', ['Build models that forecast demand, risk or behaviour', 'Work in healthcare, finance, e-commerce, research and more', 'Grow toward ML engineer, lead data scientist or analytics manager'], ['Python|Statistics & probability|Linear algebra basics', 'SQL|Pandas & NumPy|Data cleaning|Exploratory analysis', 'Dashboards (Power BI/Tableau)|Kaggle datasets|End-to-end analysis project', 'Machine learning (scikit-learn)|Feature engineering|Model evaluation|Intro to deep learning', 'Deploy a model (Flask/FastAPI)|GitHub portfolio|Case-study write-ups|Interview practice']],
['Data Analyst', '📈', 'data', 'Turns raw numbers into reports and dashboards that guide business decisions.', ['Build dashboards that teams use every day', 'Work in almost any industry that collects data', 'Grow toward data scientist, BI developer or analytics manager'], ['Excel|Statistics basics|SQL basics', 'Advanced SQL|Python & Pandas|Data cleaning', 'Power BI or Tableau|Business dashboards|3 portfolio analyses', 'A/B testing|Storytelling with data|Domain knowledge (sales, finance, operations)', 'Portfolio site|Resume with measurable results|Mock interviews|Internships']],
['Java Developer', '☕', 'java', 'Builds reliable backend, enterprise and Android applications with Java.', ['Build secure, large-scale enterprise and banking systems', 'Work on backend services and Android apps', 'Grow toward senior developer, architect or tech lead'], ['Java syntax & OOP|Collections|Exceptions|Git', 'Data structures & algorithms|JDBC & SQL|Multithreading basics', 'Spring Boot REST APIs|Hibernate/JPA|A complete CRUD app', 'Microservices|Spring Security|Testing (JUnit, Mockito)|Docker', 'Deploy to the cloud|System design basics|DSA practice|Interview prep']],
['Full Stack Developer', '🧩', 'web', 'Builds the whole product: the interface, the server and the database.', ['Ship complete products from database to user interface', 'Join startups where one person covers many layers', 'Grow toward tech lead, architect or founder'], ['HTML & CSS|JavaScript|Git & GitHub', 'React (or similar)|Responsive design|Working with APIs', 'Node.js & Express|SQL or MongoDB|Authentication', 'TypeScript|Testing|Docker|CI/CD basics', 'Deploy a full project|Portfolio of 3 apps|System design basics|Interviews']],
['Frontend Developer', '🎨', 'web', 'Creates the fast, accessible interfaces people see and use.', ['Create interfaces used by thousands or millions of people', 'Work in product companies, agencies or freelance', 'Grow toward UI engineer or frontend lead'], ['Semantic HTML|CSS (Flexbox, Grid)|JavaScript fundamentals', 'React|State management|Accessibility', 'Responsive projects|Consuming APIs|Animations', 'TypeScript|Testing|Performance & Core Web Vitals', 'Portfolio site|Open-source contributions|Interview practice']],
['Backend Developer', '🗄️', 'node', 'Builds the servers, APIs and databases that power applications.', ['Design the APIs and systems behind apps', 'Handle scale, data and security', 'Grow toward senior backend, platform or architect roles'], ['One language (Python, Java or Node.js)|HTTP & REST|Git', 'SQL & database design|Authentication|Caching basics', 'Build REST APIs|Background jobs|Write tests', 'Docker|Message queues|Scaling & monitoring|Security basics', 'Deploy to the cloud|Document your APIs|System design|Interviews']],
['AI / ML Engineer', '🤖', 'AI', 'Builds and ships machine-learning and AI features inside real products.', ['Build products that see, read, translate and recommend', 'Add AI features to real applications', 'Grow toward research engineer, ML lead or AI architect'], ['Python|Linear algebra|Probability & statistics|Calculus basics', 'Machine learning|Neural networks|PyTorch or TensorFlow', 'A computer-vision or NLP project|Kaggle competitions', 'LLMs & prompt engineering|Fine-tuning basics|MLOps basics', 'Deploy a model as an API|Read research papers|Portfolio|Interviews']],
['DevOps Engineer', '⚙️', 'cloud', 'Automates how software is built, tested, released and monitored.', ['Automate builds, tests and releases', 'Keep products reliable for many users', 'Grow toward SRE, platform engineer or cloud architect'], ['Linux & shell|Networking basics|Git', 'Docker|CI/CD (GitHub Actions, Jenkins)|Scripting (Bash/Python)', 'Kubernetes|Terraform|A cloud provider (AWS, Azure or GCP)', 'Monitoring (Prometheus, Grafana)|Security basics|Reliability practices', 'A full pipeline project|Cloud certification|Interviews']],
['Cyber Security Analyst', '🛡️', 'security', 'Protects systems, networks and people from attacks.', ['Defend systems and data from real threats', 'Work in security operations, penetration testing or compliance', 'Grow toward security engineer or security lead'], ['Networking|Linux|Operating-system fundamentals|Core security concepts', 'Web security (OWASP Top 10)|Cryptography basics|Scripting', 'A home lab|CTF practice (TryHackMe, Hack The Box)|Vulnerability scanning', 'Incident response|SIEM tools|Penetration-testing basics', 'Certifications (Security+, CEH)|Public write-ups|Interviews']],
['Mobile App Developer', '📱', 'app', 'Builds apps for Android and iOS.', ['Publish apps people install on their phones', 'Work in startups, product companies or independently', 'Grow toward senior mobile engineer or product roles'], ['Programming basics|Kotlin, Swift or Dart (Flutter)|Git', 'UI layouts|Navigation|State management', 'Build 3 apps that use APIs|Local storage|Firebase', 'Authentication|Push notifications|Testing|Performance', 'Publish to Play Store or App Store|Portfolio|Interviews']],
['Cloud Engineer', '☁️', 'cloud', 'Designs and runs applications on cloud platforms.', ['Run applications reliably on the cloud', 'Cut costs and improve security for companies', 'Grow toward cloud or solutions architect'], ['Linux|Networking|Virtualisation concepts', 'One provider (AWS, Azure or GCP)|Compute, storage, databases|IAM', 'Deploy apps|Serverless|Infrastructure as code (Terraform)', 'Security & cost optimisation|Monitoring|Containers & Kubernetes', 'Entry-level cloud certification|Projects|Interviews']],
['UI/UX Designer', '✏️', 'design', 'Designs products that are easy and enjoyable to use.', ['Design products people find easy to use', 'Work in product teams, agencies or freelance', 'Grow toward product designer or design lead'], ['Design principles|Colour & typography|User-research basics', 'Figma|Wireframes & prototypes|Design systems', '3 case studies|Usability testing|Accessibility', 'Interaction design|Handoff to developers|Basic HTML & CSS', 'Portfolio website|Design challenges|Interviews']]
];
pages.achieve = () => {
  view.innerHTML = page('Achieve', 'Pick the role you want to become and see the roadmap to get there.') + `<section class="sec"><div class="wrap"><fieldset><legend>Which role do you want to become?</legend><div class="roles">${ROLES.map(r => `<label class="role"><input type="radio" name="role" value="${e(r[0])}"><span>${r[1]} ${e(r[0])}</span></label>`).join('')}</div></fieldset>
  <div id="rm" style="margin-top:34px"><p class="empty">Choose a role above to see what you can achieve and what to learn.</p></div></div></section>`;
  document.querySelectorAll('input[name=role]').forEach(i => i.onchange = () => {
    const r = ROLES.find(x => x[0] === i.value);
    $('#rm').innerHTML = `<div class="box"><h2>${r[1]} ${e(r[0])}</h2><p>${e(r[3])}</p><h3>What you can achieve</h3><ul class="goals">${r[4].map(g => `<li>${e(g)}</li>`).join('')}</ul>
    <h3 style="margin-top:26px">Your roadmap</h3><ol class="road">${r[5].map((st, k) => `<li><h3>${STAGES[k]}</h3>${st.split('|').map(t => `<span class="pill">${e(t)}</span>`).join('')}</li>`).join('')}</ol>
    <a class="btn" href="#/opportunities?s=${encodeURIComponent(r[2])}">Find related opportunities</a></div>`;
    $('#rm').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
};
function authForm(title, fields, submit, extra = '') {
  view.innerHTML = `<div class="wrap"><div class="box narrow" style="max-width:${extra ? 640 : 480}px"><h2>${title}</h2><form id="f" novalidate>${fields}${extra}<p class="err" id="err" role="alert"></p><button class="btn" style="width:100%;justify-content:center;margin-top:8px">${submit}</button></form></div></div>`;
}
const field = (n, l, t = 'text', ac = '') => `<label for="${n}">${l}</label><input id="${n}" name="${n}" type="${t}" autocomplete="${ac}" required>`;
function bindForm(handler) { const f = $('#f'); f.onsubmit = async ev => { ev.preventDefault(); const btn = f.querySelector('button'), er = $('#err'); er.textContent = ''; btn.disabled = true; const t = btn.textContent; btn.textContent = 'Please wait…';
  try { await handler(Object.fromEntries(new FormData(f))); } catch (x) { er.textContent = x.message; } btn.disabled = false; btn.textContent = t; }; }
pages.login = () => {
  authForm('User login', field('identifier', 'Username or email', 'text', 'username') + field('password', 'Password', 'password', 'current-password'), 'Login', '<p style="font-size:14px">New here? <a href="#/register">Register</a></p>');
  bindForm(async d => { const r = await api('/login', { method: 'POST', body: d }); me.user = r.user; const back = sessionStorage.dvReturn; sessionStorage.removeItem('dvReturn'); location.hash = back || '#/opportunities'; route(); });
};
pages.register = () => {
  const pay = `<div class="pay"><div class="qr"><img src="/qr.png" alt="Dharmovix UPI payment QR code" onerror="this.replaceWith('Add qr.png to /public')"></div><div><div class="fee">Registration Fee: ₹49</div><p style="margin:6px 0 0">Scan the QR code and pay ₹49 to complete registration.</p></div></div>`;
  authForm('Create your account', field('full_name', 'Full name', 'text', 'name') + field('username', 'Username', 'text', 'username') + field('email', 'Email', 'email', 'email') + field('password', 'Password', 'password', 'new-password') + field('confirm_password', 'Confirm password', 'password', 'new-password') +
    pay + `<label for="payment_ref">UPI transaction / UTR reference (after paying ₹49)</label><input id="payment_ref" name="payment_ref" required>`, 'Submit registration', '<p style="font-size:14px">Already approved? <a href="#/login">Login</a></p>');
  bindForm(async d => { await api('/register', { method: 'POST', body: d });
    view.innerHTML = `<div class="wrap"><div class="box narrow" style="text-align:center"><h2>Registration submitted</h2><p>Registration submitted successfully. Please wait a few minutes while we review your registration. You will receive an email once your account has been approved.</p><a class="btn" href="#/">Back to home</a></div></div>`; });
};
pages.profile = async () => {
  if (!me.user) { sessionStorage.dvReturn = location.hash; return location.hash = '#/login'; }
  const apps = await api('/my-applications').catch(() => []), u = me.user;
  view.innerHTML = page('Your profile', 'Your account and applications.') + `<div class="wrap sec"><div class="box"><div style="display:flex;align-items:center;gap:18px;margin-bottom:20px">${u.avatar_url ? `<img src="${e(u.avatar_url)}" alt="Profile photo" style="width:84px;height:84px;object-fit:cover;border-radius:50%">` : `<div style="width:84px;height:84px;border-radius:50%;background:#f1ead8;display:grid;place-items:center;font-size:28px">${e((u.full_name || '?').slice(0,1).toUpperCase())}</div>`}<form id="avatar-form"><label for="avatar-image">Profile photo (JPG, PNG or WebP, max 5 MB)</label><input id="avatar-image" type="file" name="image" accept="image/jpeg,image/png,image/webp" required><button class="btn" style="margin-top:10px">Upload photo</button><p class="err" id="avatar-error" role="alert"></p></form></div><div class="tbl"><table><tr><th>Full name</th><td>${e(u.full_name)}</td></tr><tr><th>Username</th><td>${e(u.username)}</td></tr><tr><th>Email</th><td>${e(u.email)}</td></tr><tr><th>Account status</th><td>${pill(u.account_status)}</td></tr><tr><th>Registered</th><td>${fmtDate(u.created_at)}</td></tr></table></div></div>
  <h2 id="apps" style="margin-top:36px">My applications</h2><div class="box tbl">${apps.length ? `<table><tr><th>Opportunity</th><th>Category</th><th>Applied</th><th>Status</th></tr>${apps.map(a => `<tr><td><a href="#/opportunity/${a.opportunity_id}">${e(a.title)}</a></td><td>${e(a.category)}</td><td>${fmtDate(a.applied_at)}</td><td>${pill(a.status)}</td></tr>`).join('')}</table>` : '<p class="empty">You have not applied yet. <a href="#/opportunities">Find an opportunity</a></p>'}</div></div>`;
  const af = $('#avatar-form'); if (af) af.onsubmit = async ev => { ev.preventDefault(); const err = $('#avatar-error'), btn = af.querySelector('button'); err.textContent = ''; btn.disabled = true; const data = new FormData(); const file = $('#avatar-image').files[0]; if (!file) { err.textContent = 'Choose an image to upload.'; btn.disabled = false; return; } data.append('image', file); try { const r = await api('/profile/avatar', { method: 'POST', body: data }); me.user.avatar_url = r.avatar_url; toast('Profile photo updated.'); pages.profile(); } catch (x) { err.textContent = x.message; } finally { btn.disabled = false; } };
  if (location.hash === '#/applications') $('#apps').scrollIntoView();
};

/* ---------- Admin ---------- */
pages.adminLogin = () => {
  authForm('Admin login', field('email', 'Email', 'email', 'username') + field('password', 'Password', 'password', 'current-password'), 'Login', '<p style="font-size:14px"><a href="#/">← Back to website</a></p>');
  bindForm(async d => { await api('/admin/login', { method: 'POST', body: d }); me.admin = { email: d.email }; location.hash = '#/admin/dashboard'; route(); });
};
const AN = [['dashboard', 'Dashboard'], ['users', 'Users'], ['opportunities', 'Opportunities'], ['add', 'Add Opportunity'], ['applications', 'Applications'], ['notifications', 'Email Notifications'], ['settings', 'Settings']];
const adminShell = (sec, inner) => { $('#nav').innerHTML = ''; $('#foot').hidden = true;
  view.innerHTML = `<div class="adm"><aside class="side" id="side"><a class="brand" href="#/admin/dashboard"><img src="/logo.png" alt="">Dharmovix</a>${AN.map(([k, l]) => `<a href="#/admin/${k}" class="${k === sec ? 'on' : ''}">${l}</a>`).join('')}<button id="aout" style="margin-top:auto">Logout</button></aside>
  <div class="admmain"><div class="admtop"><button id="ab" aria-label="Menu">☰</button><b>Admin</b></div>${inner}</div></div>`;
  $('#ab').onclick = () => $('#side').classList.toggle('open');
  $('#aout').onclick = async () => { await api('/admin/logout', { method: 'POST' }).catch(() => {}); me.admin = null; location.hash = '#/admin-login'; route(); }; };
const A = {};
A.dashboard = async () => { const s = await api('/admin/stats'), n = [['Total Users', s.users], ['Pending Users', s.pending], ['Approved Users', s.approved], ['Rejected Users', s.rejected], ['Total Opportunities', s.opportunities], ...CATS.map(c => [PLURAL[c], s.byCategory[c]]), ['Total Applications', s.applications]];
  const mx = Math.max(1, ...Object.values(s.byCategory)), mu = Math.max(1, s.users);
  adminShell('dashboard', `<h1>Dashboard</h1><div class="stats">${n.map(([l, v]) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div class="panel"><h3>Opportunities by category</h3>${CATS.map(c => `<div class="bar"><span>${PLURAL[c]}</span><i style="width:${s.byCategory[c] / mx * 100}%"></i><b>${s.byCategory[c]}</b></div>`).join('')}</div>
  <div class="panel"><h3>Users by status</h3>${[['Pending', s.pending], ['Approved', s.approved], ['Rejected', s.rejected]].map(([l, v]) => `<div class="bar"><span>${l}</span><i style="width:${v / mu * 100}%"></i><b>${v}</b></div>`).join('')}</div></div>`); };
A.users = async () => {
  adminShell('users', `<h1>Registered users</h1><div class="panel"><div class="toolbar"><input id="uq" type="search" placeholder="Search name, username or email"><select id="us"><option value="">All statuses</option><option>Pending</option><option>Approved</option><option>Rejected</option></select></div><div class="tbl" id="ut"></div></div>`);
  const load = async () => { const d = await api(`/admin/users?q=${encodeURIComponent($('#uq').value)}&status=${$('#us').value}`);
    $('#ut').innerHTML = d.length ? `<table><tr><th>Full name</th><th>Username</th><th>Email</th><th>Registered</th><th>Payment</th><th>Account</th><th>Actions</th></tr>${d.map(u => `<tr><td>${e(u.full_name)}</td><td>${e(u.username)}</td><td>${e(u.email)}</td><td>${fmtDate(u.created_at)}</td><td>${pill(u.payment_status)}</td><td>${pill(u.account_status)}</td>
    <td><div class="acts"><button class="btn sm ghost" data-a="view" data-i="${u.id}">View</button>${u.payment_status !== 'Verified' ? `<button class="btn sm navy" data-a="verify-payment" data-i="${u.id}">Verify payment</button>` : ''}${u.account_status !== 'Approved' ? `<button class="btn sm ok" data-a="approve" data-i="${u.id}">Approve</button>` : ''}${u.account_status !== 'Rejected' ? `<button class="btn sm bad" data-a="reject" data-i="${u.id}">Reject</button>` : ''}</div></td></tr>`).join('')}</table>` : '<p class="empty">No users match.</p>';
    $('#ut').onclick = async ev => { const b = ev.target.closest('button'); if (!b) return; const u = d.find(x => x.id == b.dataset.i);
      if (b.dataset.a === 'view') return modal(`<h3>${e(u.full_name)}</h3><div class="tbl"><table>${['username', 'email', 'payment_status', 'payment_ref', 'account_status', 'created_at', 'approved_at'].map(k => `<tr><th>${k.replace(/_/g, ' ')}</th><td>${e(u[k] || '-')}</td></tr>`).join('')}</table></div><button class="btn ghost" onclick="this.closest('.modal').remove()" style="margin-top:14px">Close</button>`);
      if (b.dataset.a === 'reject' && !await confirmBox('Reject this registration?', 'Reject')) return;
      try { await api(`/admin/users/${u.id}/${b.dataset.a}`, { method: 'POST' }); toast('Done.'); load(); } catch (x) { toast(x.message, true); } }; };
  let t; $('#uq').oninput = () => { clearTimeout(t); t = setTimeout(load, 250); }; $('#us').onchange = load; load(); };
function oppForm(o = {}) {
  const m = modal(`<h3>${o.id ? 'Edit' : 'Add new'} opportunity</h3><form id="of">${field('title', 'Title').replace('required', `required value="${e(o.title || '')}"`)}
  <label>Category</label><select name="category" required><option value="">Choose…</option>${CATS.map(c => `<option ${o.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
  <label>Description</label><textarea name="description" required>${e(o.description || '')}</textarea><label>Date</label><input type="date" name="date" value="${e(o.date || '')}">
  <label>Registration link</label><input type="url" name="registration_link" placeholder="https://" value="${e(o.registration_link || '')}"><label>Additional information</label><textarea name="additional_info">${e(o.additional_info || '')}</textarea>
  <label>Image (JPG, PNG or WebP, max 5 MB)</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp"><img class="preview" id="pv" alt="Preview" ${o.image ? `src="${e(imageUrl(o.image))}"` : 'hidden'}>
  <label>Status</label><select name="status"><option ${o.status === 'Unpublished' ? 'selected' : ''}>Unpublished</option><option ${o.status === 'Published' || !o.id ? 'selected' : ''}>Published</option></select>
  <p style="font-size:13px;color:var(--mute);margin:6px 0 0">Publishing automatically emails every approved user.</p><p class="err" id="oe" role="alert"></p><div class="acts"><button class="btn">${o.id ? 'Save changes' : 'Publish opportunity'}</button><button type="button" class="btn ghost" id="cx">Cancel</button></div></form>`);
  const f = m.querySelector('#of'); m.querySelector('#cx').onclick = () => { m.close(); if (!o.id && location.hash === '#/admin/add') location.hash = '#/admin/opportunities'; };
  const fi = f.elements.image; fi.onchange = () => { const x = fi.files[0]; if (!x) return; if (x.size > 5 * 1024 * 1024) { fi.value = ''; return m.querySelector('#oe').textContent = 'Image must be 5 MB or smaller.'; } const p = m.querySelector('#pv'); p.src = URL.createObjectURL(x); p.hidden = false; };
  f.onsubmit = async ev => { ev.preventDefault(); const b = f.querySelector('button'); b.disabled = true; b.textContent = 'Saving…';
    try { await api(o.id ? '/admin/opportunities/' + o.id : '/admin/opportunities', { method: o.id ? 'PUT' : 'POST', body: new FormData(f) }); m.close(); toast(o.id ? 'Saved.' : 'Published.'); location.hash = '#/admin/opportunities'; route(); }
    catch (x) { m.querySelector('#oe').textContent = x.message; b.disabled = false; b.textContent = o.id ? 'Save changes' : 'Publish opportunity'; } };
}
A.opportunities = async () => { const d = await api('/admin/opportunities');
  adminShell('opportunities', `<h1>Opportunities</h1><div class="panel"><div class="toolbar"><button class="btn" id="new">Add opportunity</button></div><div class="tbl">${d.length ? `<table><tr><th>Title</th><th>Category</th><th>Date</th><th>Status</th><th>Emails</th><th>Actions</th></tr>${d.map(o => `<tr><td>${e(o.title)}</td><td>${e(o.category)}</td><td>${fmtDate(o.date)}</td><td>${pill(o.status)}</td><td>${o.sent} sent${o.failed ? `, <b style="color:var(--bad)">${o.failed} failed</b>` : ''}</td>
  <td><div class="acts"><button class="btn sm ghost" data-a="edit" data-i="${o.id}">Edit</button><button class="btn sm navy" data-a="toggle" data-i="${o.id}">${o.status === 'Published' ? 'Unpublish' : 'Publish'}</button>${o.status === 'Published' ? `<button class="btn sm" data-a="notify" data-i="${o.id}">Notify users</button>` : ''}<button class="btn sm bad" data-a="del" data-i="${o.id}">Delete</button></div></td></tr>`).join('')}</table>` : '<p class="empty">No opportunities yet.</p>'}</div></div>`);
  $('#new').onclick = () => oppForm();
  view.querySelector('.tbl').onclick = async ev => { const b = ev.target.closest('button'); if (!b) return; const o = d.find(x => x.id == b.dataset.i);
    try { if (b.dataset.a === 'edit') return oppForm(o);
      if (b.dataset.a === 'notify') { const r = await api(`/admin/opportunities/${o.id}/notify`, { method: 'POST' }); return toast(r.queued ? `Sending email to ${r.queued} approved user${r.queued > 1 ? 's' : ''}.` : 'All approved users have already been emailed.'); }
      if (b.dataset.a === 'del') { if (!await confirmBox('Are you sure you want to delete this opportunity?')) return; await api('/admin/opportunities/' + o.id, { method: 'DELETE' }); }
      if (b.dataset.a === 'toggle') await api(`/admin/opportunities/${o.id}/status`, { method: 'POST', body: { status: o.status === 'Published' ? 'Unpublished' : 'Published' } });
      toast('Done.'); route(); } catch (x) { toast(x.message, true); } }; };
A.add = async () => { await A.opportunities(); location.hash.endsWith('add') && oppForm(); };
A.applications = async () => { const d = await api('/admin/applications');
  adminShell('applications', `<h1>Applications</h1><div class="panel tbl">${d.length ? `<table><tr><th>Applicant</th><th>Email</th><th>Opportunity</th><th>Applied</th><th>Status</th></tr>${d.map(a => `<tr><td>${e(a.full_name)}</td><td>${e(a.email)}</td><td>${e(a.title)}</td><td>${fmtDate(a.applied_at)}</td>
  <td><select data-i="${a.id}" aria-label="Status">${['Applied', 'Under Review', 'Accepted', 'Rejected'].map(s => `<option ${a.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></td></tr>`).join('')}</table>` : '<p class="empty">No applications yet.</p>'}</div>`);
  view.onchange = async ev => { if (ev.target.dataset.i) try { await api(`/admin/applications/${ev.target.dataset.i}/status`, { method: 'POST', body: { status: ev.target.value } }); toast('Status updated.'); } catch (x) { toast(x.message, true); } }; };
A.notifications = async () => { const [d, o] = await Promise.all([api('/admin/notifications'), api('/admin/opportunities')]), bad = o.filter(x => x.failed);
  adminShell('notifications', `<h1>Email notifications</h1>${bad.length ? `<div class="panel"><b>Failed deliveries</b>${bad.map(x => `<div class="switch"><span>${e(x.title)} – ${x.failed} failed</span><button class="btn sm" data-r="${x.id}">Retry</button></div>`).join('')}</div>` : ''}
  <div class="panel tbl">${d.length ? `<table><tr><th>Opportunity</th><th>Type</th><th>Recipient</th><th>Status</th><th>Sent</th><th>Error</th></tr>${d.map(n => `<tr><td>${e(n.title)}</td><td>${e(n.notification_type)}</td><td>${e(n.email)}</td><td>${pill(n.status)}</td><td>${n.sent_at ? fmtDate(n.sent_at) : '-'}</td><td>${e(n.error_message || '')}</td></tr>`).join('')}</table>` : '<p class="empty">Notifications appear here when you publish an opportunity.</p>'}</div>`);
  view.onclick = async ev => { const id = ev.target.dataset.r; if (!id) return; await api(`/admin/opportunities/${id}/retry-notifications`, { method: 'POST' }); toast('Retrying in the background. Refresh in a moment.'); }; };
A.settings = async () => { const s = await api('/admin/settings'), sw = [['notify_new_opportunity', 'New opportunity notifications'], ['notify_approval', 'Approval emails'], ['notify_registration', 'Registration confirmation emails']];
  adminShell('settings', `<h1>Settings</h1><div class="panel"><h3>Email notifications</h3>${s.smtp_configured ? `<p>SMTP host is configured${s.smtp_user ? ` for ${e(s.smtp_user)}` : ''}. Send a test message to the admin email to verify delivery.</p><button class="btn" id="smtp-test">Send test email</button><p class="err" id="smtp-test-error" role="alert"></p>` : '<p class="err">SMTP is not configured on the server, so emails cannot be delivered. Add SMTP settings to your .env file and restart the server.</p>'}<div style="margin-top:14px">${sw.map(([k, l]) => `<label class="switch" style="margin:0"><span>${l}</span><input type="checkbox" data-k="${k}" ${s[k] ? 'checked' : ''}></label>`).join('')}</div><p style="font-size:13px;color:var(--mute)">Gmail setup: use smtp.gmail.com, port 587, your Gmail address, and a Google App Password (not your normal Gmail password). Set FROM_EMAIL to the same Gmail address.</p></div>
  <div class="panel" style="max-width:480px"><h3>Change password</h3><form id="f">${field('current', 'Current password', 'password', 'current-password')}${field('next', 'New password', 'password', 'new-password')}<p class="err" id="err"></p><button class="btn">Change password</button></form></div>`);
  const smtpTest = $('#smtp-test'); if (smtpTest) smtpTest.onclick = async () => { smtpTest.disabled = true; $('#smtp-test-error').textContent = ''; try { const r = await api('/admin/test-email', { method: 'POST', body: {} }); toast(r.message || 'Test email sent.'); } catch (x) { $('#smtp-test-error').textContent = x.message; } finally { smtpTest.disabled = false; } };
  view.onchange = async ev => { if (ev.target.dataset.k) try { await api('/admin/settings', { method: 'PUT', body: { [ev.target.dataset.k]: ev.target.checked } }); toast('Saved.'); } catch (x) { toast(x.message, true); } };
  bindForm(async d => { await api('/admin/change-password', { method: 'POST', body: d }); toast('Password changed. Please log in again.'); me.admin = null; location.hash = '#/admin-login'; route(); }); };

/* ---------- Router ---------- */
async function route() {
  document.getElementById('foot').hidden = false; view.onchange = view.onclick = null;
  const [path, qs] = (location.hash || '#/').slice(1).split('?'), params = new URLSearchParams(qs || ''), seg = path.split('/').filter(Boolean);
  try { me = await api('/me'); } catch { me = { user: null, admin: null }; }
  window.scrollTo(0, 0);
  try {
    if (seg[0] === 'admin-login') { nav(); $('#nav').innerHTML = ''; return me.admin ? (location.hash = '#/admin/dashboard') : pages.adminLogin(); }
    if (seg[0] === 'admin') { if (!me.admin) return location.hash = '#/admin-login'; return A[seg[1] && A[seg[1]] ? seg[1] : 'dashboard'](); }
    nav();
    if (!seg.length) return pages.home();
    if (seg[0] === 'opportunity') return pages.opportunity(+seg[1]);
    if (seg[0] === 'applications') return pages.profile();
    if (pages[seg[0]]) return pages[seg[0]](params);
    view.innerHTML = '<div class="wrap narrow"><h2>Page not found</h2><a class="btn" href="#/">Go home</a></div>';
  } catch (x) { view.innerHTML = `<div class="wrap narrow"><h2>${e(x.message)}</h2></div>`; if (x.status === 401 && seg[0] === 'admin') { me.admin = null; location.hash = '#/admin-login'; } }
  view.focus({ preventScroll: true });
}
window.addEventListener('hashchange', route);
window.addEventListener('pageshow', ev => { if (ev.persisted) route(); }); // re-check session after back/forward cache
intro(); route();
